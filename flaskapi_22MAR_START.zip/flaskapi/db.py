stores = {}
items = {}